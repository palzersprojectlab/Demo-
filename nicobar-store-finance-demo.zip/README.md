# Nicobar Store Finance Portal — Demo

A React + Vite interactive prototype for a multi-store finance portal.

## Run locally

1. Install Node.js (LTS): https://nodejs.org/
2. Extract this project folder.
3. Open a terminal in this folder.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL printed by Vite, usually http://localhost:5173.

## Demo access

The login screen provides demo roles:
- Head Office Admin — all stores and approvals
- Jio World Drive Manager
- Jio World Drive Employee
- Store B Manager
- Store C Manager

No password is required in this prototype.

## Important limitations

- This is a frontend demonstration, not a production finance system.
- Data is stored in the current browser's localStorage. It does not sync across devices or users.
- Demo login selection is not real authentication.
- Frontend filtering is not a security boundary.
- Receipt files are stored as browser data URLs for demonstration only.
- Before using real employee or financial data, connect Supabase Auth, PostgreSQL, private Storage buckets and strict Row Level Security policies.
- Have the cash-hand-over and petty-cash accounting workflows reviewed by the finance team before production use.

## GitHub

Create a repository named `nicobar-store-finance-demo`, upload the extracted files and commit them. Do not upload real credentials or `.env` secrets.
